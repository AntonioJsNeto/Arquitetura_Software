package Exemplo2.Padrao;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try{
            Scanner sc = new Scanner(System.in);
            Distancia distancia = new Distancia(1500);

            System.out.println("DESEJA ESCOLHER QUAL EMPRESA?");
            int n = sc.nextInt();

            double valorTaxa = ListaEmpresa.values()[n].taxa(distancia);

            System.out.println(valorTaxa);

        }catch (ArrayIndexOutOfBoundsException erro){
            System.out.println(erro.getMessage());
        }
    }
}
