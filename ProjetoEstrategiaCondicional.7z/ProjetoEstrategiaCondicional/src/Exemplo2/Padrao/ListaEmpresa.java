package Exemplo2.Padrao;

public enum ListaEmpresa implements Taxa {

    ABC{
        @Override
        public double taxa(Distancia distancia) {
            return distancia.getKm() * 0.10;
        }
    },

    CBA{
        @Override
        public double taxa(Distancia distancia) {
            return distancia.getKm() * 0.20;
        }
    },

    XPTO{
        @Override
        public double taxa(Distancia distancia){
            return distancia.getKm() * 0.30;
        }
    };
}
