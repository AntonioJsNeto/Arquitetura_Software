package Exemplo2.Padrao;

public class Distancia {
    private double km;

    public Distancia(double km) {
        this.km = km;
    }

    public double getKm() {
        return km;
    }

    public void setKm(double km) {
        this.km = km;
    }

    @Override
    public String toString() {
        return "Distancia{" +
                "km=" + km +
                '}';
    }
}
