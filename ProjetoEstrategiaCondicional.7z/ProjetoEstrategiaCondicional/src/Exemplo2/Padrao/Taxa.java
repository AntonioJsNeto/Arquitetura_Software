package Exemplo2.Padrao;

public interface Taxa {
    public double taxa(Distancia distancia);
}
