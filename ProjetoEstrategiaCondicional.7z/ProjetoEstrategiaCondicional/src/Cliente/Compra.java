package Cliente;

public class Compra {

    private double valor;
    private double valorDesconto;

    public Compra (double valor){
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getValorDesconto() {
        return valorDesconto;
    }

    public void setValorDesconto(double valorDesconto) {
        this.valorDesconto = valorDesconto;
    }

    @Override
    public String toString() {
        return "Compra{" +
                "valor=" + valor +
                ", valorDesconto=" + valorDesconto +
                '}';
    }
}
