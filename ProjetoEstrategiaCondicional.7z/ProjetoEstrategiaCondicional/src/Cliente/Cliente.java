package Cliente;

import Padrao.*;

import java.util.Scanner;

public class Cliente {
    public static void main(String[] args) {
        try {
            Compra compra = new Compra(100);
            Scanner sc = new Scanner(System.in);

            System.out.println("DESEJA ESCOLHER QUAL DESCONTO?");
            int n = sc.nextInt();

            double valorDesc = ListasDescontos.values()[n].desconto(compra);

            System.out.println(valorDesc);
        }catch (ArrayIndexOutOfBoundsException erro){
            System.out.printf(erro.getMessage());
        }

    }

    /*public static double calcularDesconto(Compra compra, String tipo){
        Desconto desconto;

        if( tipo.equals( "ValorFixo")){
            desconto = new ValorFixo();
            return desconto.desconto(compra);

        } else if (tipo.equals("ValorMinimo")) {
            desconto = new ValorMinimo();
            return desconto.desconto(compra);
        } else if (tipo.equals("Percentual")) {
            desconto = new Percentual();
            return desconto.desconto(compra);
        }else{
            throw new IllegalArgumentException("TIPO INVÁLIDO!");
        }
    }*/
}
