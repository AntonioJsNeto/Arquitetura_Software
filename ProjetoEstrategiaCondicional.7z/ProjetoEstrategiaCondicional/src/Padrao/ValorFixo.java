package Padrao;

import Cliente.Compra;

public class ValorFixo implements Desconto{

    @Override
    public double desconto(Compra compra) {

        return compra.getValor() - 10.0;
    }
}
