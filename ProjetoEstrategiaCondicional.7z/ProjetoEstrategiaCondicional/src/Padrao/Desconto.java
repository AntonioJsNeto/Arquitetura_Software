package Padrao;

import Cliente.Compra;

public interface Desconto {
    public double desconto (Compra compra);

}
