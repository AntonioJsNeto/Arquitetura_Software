package Padrao;

import Cliente.Compra;

public class ValorMinimo implements Desconto{
    @Override
    public double desconto(Compra compra) {
        return compra.getValor() - 50.0;
    }
}
