package Padrao;


import Cliente.Compra;

public class Percentual implements Desconto{

    @Override
    public double desconto(Compra compra) {
        return compra.getValor() * 0.95;
    }
}
