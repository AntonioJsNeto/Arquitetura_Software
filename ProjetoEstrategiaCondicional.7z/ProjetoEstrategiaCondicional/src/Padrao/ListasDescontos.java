package Padrao;

import Cliente.Compra;

public enum ListasDescontos implements Desconto{

    VALORFIXO{
        @Override
        public double desconto(Compra compra) {
            return compra.getValor() - 10.0;
        }
    },

    VALORMINIMO{
        @Override
        public double desconto(Compra compra) {
            return compra.getValor() - 50.0;
        }
    },

    PERCENTUAL{
        @Override
        public double desconto(Compra compra) {
            return compra.getValor() * 0.95;
        }
    };
}
